#define BUFFER_SIZE 64 // don't know how big it has to be this time since on discussion board it says they will test with t > 1000
#define IP_ADDR_SIZE 15 // ip address is 15 chars
#define MAX_CLIENT 10// said in forums that 10 clients would be the max
#define PID_SIZE 6 // pid should have 6 maximum digits

void Trans(int n);

void Sleep(int n);

int getInt(char string[BUFFER_SIZE]);

char* getTime(char* toStore);