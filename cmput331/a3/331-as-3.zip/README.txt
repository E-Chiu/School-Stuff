Chiu, Ethan Cmput 331 Assignment 3

modular inverse for part 3 was calculated using https://www.dcode.fr/modular-inverse

function used to find a modular inverse in part 4 was obtained from https://stackoverflow.com/questions/4798654/modular-multiplicative-inverse-function-in-python