CHIU, ETHAN - ASSIGNMENT 1

The code for the caesar cipher was taken in part from the caesarCipher.py included in the Assignment handouts. 

Oral discussion was had with Nathan Tang about possible edge cases of the implementations of the different caesarCipher modifications.