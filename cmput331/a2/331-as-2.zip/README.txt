CHIU, ETHAN Assignment 2

Inspiration for the decode function in part 1 was taken from https://www.dcode.fr/rail-fence-cipher under the section "How to decrypt Rail Fence cipher?".

Code was also inspired from the transposition.py file from the class resources.

Discussions had in the Cmput 331 discord were also referenced to learn to read the file in UTF-8

