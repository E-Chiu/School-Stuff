Ethan Chiu CMPUT 331 A4,

Code was borrowed from the substitution.py file provides in eclass, as well as from source code within the textbook.

Additional clarifications on A4 were recieved from Mark within the class Discord server.

