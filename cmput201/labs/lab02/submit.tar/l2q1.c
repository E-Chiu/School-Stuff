/*
cmput 201 l2q1
refrences: none
author: Ethan Chiu
*/

# include <stdio.h>

int main() {
	int number_one,number_two;
	number_one = 10;
	number_two = 5;
	printf("The total is %d\n",(number_one+10-number_two)/5);
}
