1. type 'vim ls_com.txt' to see contents
2. in vim type ':w' to save the file
3. type 'gcc -Wall -std=c99 hello.c -o hello' then you can run hello.c with the executable ./hello
4. type './hello' and the program will run
5. type 'tar -cf submit.tar ls_com.txt ls_out.txt hello.c readme.txt'
6. type 'mkdir temp' to make new directory
7. type 'cp submit.tar temp' to copy the file to the temporary directory
8. type 'tar -xf submit.tar' to untar
